import React from 'react'
import './Report.css'

function Report() {
    return (
        <div>
            <div className="topnav" id="myTopnav">
            <h1 className="heading">Candidate Progress Report</h1>
                <a href="#download"><button type="button" class="btn btn-danger">Download</button></a>
            </div>
            
            {/* <h1 className="heading">Candidate Progress Report</h1> */}
            <p className="attempt">Number Of Attempt: 1</p>
            <div className="row">
                <div className="col-6 ">
                   <div className="card1">
                       <div class="form-group  student-form">
                           <label class="col-form-label label">Candidate Name :</label>
                           <div class="label">Jwala Pratap Singh</div>
                        </div>
                        <div class="form-group  student-form">
                            <label class="col-form-label label">Exam Name :</label>
                            <div class="label">JavaScript</div>
                        </div>
                    </div>
                </div>
                <div className="col-6">
                <div className="card1">
                <div class="form-group  student-form">
                           <label class="col-form-label label1">Exam Start Time :</label>
                           <div class="label1">31/08/2021 1:10:00 PM</div>
                        </div>
                        <div class="form-group  student-form">
                            <label class="col-form-label label1">Exam End Time :</label>
                            <div class="label1">31/08/2021 2:10:00 PM</div>
                        </div>
                   </div>
                </div>
            </div>

            <div className="row">
                <div className="col-4">
                    <h1 className="score">Score: 5/10</h1>
                </div>
                <div className="col-4">
                    <h1 className="percentage">Percentage: 43%</h1>
                </div>
                <div className="col-4">
                    <h1 className="percentile">Percentile: 56</h1>
                </div>
            </div>
        <hr className="hr"/>

        <div className="card border-primary mb-3 " >
            <div className="card-header"><b>QUIZ RESULT REVIEW</b></div>
            <div className="card-body text-dark mb-2">
                <h5 className="card-title"> 1) Which type of JavaScript language is ___</h5>
                <p className="card-text">
                    <label class="container">Object-Oriented
                        <input type="checkbox" checked="checked"/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="containerTrue">Object-Based
                        <input type="checkboxTrue "/>
                        <span class="checkmarkTrue"></span>
                    </label>
                    <label class="container">Assembly-language
                        <input type="checkbox"/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="container">High-level
                        <input type="checkbox"/>
                        <span class="checkmark"></span>
                    </label>
                </p>
            </div>

            <div className="card-body text-dark mb-2">
                <h5 className="card-title"> 2) Which one of the following also known as Conditional Expression:</h5>
                <p className="card-text">
                    <label class="container">Alternative to if-else
                        <input type="checkbox" checked="checked"/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="container">witch statement
                        <input type="checkbox "/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="container">If-then-else statement
                        <input type="checkbox"/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="containerTrue">immediate if
                        <input type="checkbox"/>
                        <span class="checkmarkTrue"></span>
                    </label>
                </p>
            </div>

            <div className="card-body text-dark mb-2">
                <h5 className="card-title"> 3) The "function" and " var" are known as:</h5>
                <p className="card-text">
                    <label class="container">Keywords
                        <input type="checkbox" checked="checked"/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="container">Data types
                        <input type="checkbox "/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="containerTrue">Declaration statements
                        <input type="checkbox"/>
                        <span class="checkmarkTrue"></span>
                    </label>
                    <label class="container">Prototypes
                        <input type="checkbox"/>
                        <span class="checkmark"></span>
                    </label>
                </p>
            </div>

            <div className="card-body text-dark mb-2">
                <h5 className="card-title"> 4) Which one of the following is the correct way for calling the JavaScript code?</h5>
                <p className="card-text">
                    <label class="containerTrue">Function/Method
                        <input type="checkbox" checked="checked"/>
                        <span class="checkmarkTrue"></span>
                    </label>
                    <label class="container">RMI
                        <input type="checkbox "/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="container">Triggering Event
                        <input type="checkbox"/>
                        <span class="checkmark"></span>
                    </label>
                    <label class="container">Preprocessor
                        <input type="checkbox"/>
                        <span class="checkmark"></span>
                    </label>
                </p>
            </div>

        </div>

        </div>
    )
}

export default Report
