import React from 'react'
import './Report.css'

function Report() {
    return (
        <div>
            <h1 className="heading">Candidate Progress Report</h1>
            <p className="attempt">Number Of Attempt: 1</p>
            <div className="row">
                <div className="col-6 ">
                   <div className="card1">
                       <div class="form-group  student-form">
                           <label class="col-form-label label">Candidate Name :</label>
                           <div class="label">Jwala Pratap</div>
                        </div>
                        <div class="form-group  student-form">
                            <label class="col-form-label label">Exam Name :</label>
                            <div class="label">JavaScript</div>
                        </div>
                    </div>
                </div>
                <div className="col-6">
                <div className="card1">
                <div class="form-group  student-form">
                           <label class="col-form-label label">Exam Start Time :</label>
                           <div class="label">31/08/2021 1:10:00 PM</div>
                        </div>
                        <div class="form-group  student-form">
                            <label class="col-form-label label">Exam End Time :</label>
                            <div class="label">31/08/2021 2:10:00 PM</div>
                        </div>
                   </div>
                </div>
            </div>

            <div className="row">
                <div className="col-4">
                    <h1 className="score">Score: 5/10</h1>
                </div>
                <div className="col-4">
                    <h1 className="percentage">Percentage: 43%</h1>
                </div>
                <div className="col-4">
                    <h1 className="percentile">Percentile: 56</h1>
                </div>
            </div>

        </div>
    )
}

export default Report
