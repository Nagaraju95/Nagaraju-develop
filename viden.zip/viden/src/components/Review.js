import React, { Component } from 'react';
import './Report.css';

class Review extends Component{
    render(){
        return(
            <div className="card  mb-3 result_card" >
                <div className="card-header text-center"><b>QUIZ RESULT REVIEW</b></div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 1. Inside which HTML element do we put JavaScript?</h5>
                    <p className="card-text">
                        <label class="container">javascript
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">scripting
                            <input type="checkboxTrue " />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">script
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">js
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>

                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 2. What is the full form of SPA</h5>
                    <p className="card-text">
                        <label class="container">Secrured and Progressive App
                            <input type="checkbox" checked="checked" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">Solid Principles of Application
                            <input type="checkbox " />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">Single Page Application
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">None of the above
                            <input type="checkbox" />
                            <span class="checkmar"></span>
                        </label>
                    </p>
                </div>

                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 3. Which of these keyword is NOT used to declare a variable in Javascript?</h5>
                    <p className="card-text">
                        <label class="container">dim
                            <input type="checkbox" checked="checked" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">let
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">const
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">var
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>

                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 4. What does the noscript tag used for?</h5>
                    <p className="card-text">
                        <label class="container">Displayed text in non-JavaScript browsers.
                            <input type="checkbox" checked="checked" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">Prevents Script Execution
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">Requests user not to run scripts
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">None of the above
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 5)How do you write "Hello World" in an alert box?</h5>
                    <p className="card-text">
                        <label class="container">alertBox("Hello World");
                            <input type="checkbox" checked="checked" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">msgBox("Hello World");
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">display 'Hello World'
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">alert('Hello World');
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                    </p>
                </div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 6)Which is NOT the Javascript framework/library?</h5>
                    <p className="card-text">
                        <label class="container">Angular
                            <input type="checkbox" checked="checked" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">Ember
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">.Net Core
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">React
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 7)Which method is used to return a copy of filtered array when predicate is passed?</h5>
                    <p className="card-text">
                        <label class="container">concat
                            <input type="checkbox" checked="checked" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">filter
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">search
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">some
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 8. Which of the following is popular server side Javascript framework mainly used to write API?</h5>
                    <p className="card-text">
                        <label class="container">Angular
                            <input type="checkbox" checked="checked" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">Express
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">React
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">Kinetic
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 9. Which method is best suited to redirect to another url?</h5>
                    <p className="card-text">
                        <label class="container">response.redirect
                            <input type="checkbox" checked="checked" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">window.location
                            <input type="checkbox" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">url.transfer
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">window.redirect
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>
                <div className="card-body text-dark mb-2">
                    <h5 className="card-title"> 10. Which method is used to execute another method in a given time interval?</h5>
                    <p className="card-text">
                        <label class="container">setTimeout()
                            <input type="checkbox" checked="checked" />
                            <span class="checkmarkTrue"></span>
                        </label>
                        <label class="container">delayMethod()
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">evalLater()
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                        <label class="container">timer()
                            <input type="checkbox" />
                            <span class="checkmark"></span>
                        </label>
                    </p>
                </div>
            </div>
        )
    }
}


export default Review;