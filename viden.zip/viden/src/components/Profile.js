import React from 'react';
import './Profile.css';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';
import AssignmentTurnedInOutlinedIcon from '@material-ui/icons/AssignmentTurnedInOutlined';

const Profile = () => {
    return (
        <div>
            <div className="row profile-section">
                <div className="col-lg-2 sidebar">
                    <h4>Assessment</h4>
                    <ul className="nav nav-pills flex-sm-column flex-row  justify-content-between ">
                        <li className="nav-item">
                            <a href="#" className="nav-link  text-truncate">
                                <span >Neet</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" className="nav-link  text-truncate">
                                <span >JEE</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" className="nav-link  text-truncate">
                                <span >JEE Advanced</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" className="nav-link  text-truncate">
                                <span >JAVA</span>
                            </a>
                        </li>

                    </ul>
                </div>
                <div className="col-lg-10">
                    <div className="row">
                        <h5 className="fw-bold">Hello Mounika Chaudhari</h5>
                        <p>Take the first step to your goal today</p>
                        <div className="col-sm-4">
                            <div className="card reportcard">
                                <div className="card-body">
                                    <h6 className="card-title">
                                        <AssignmentTurnedInOutlinedIcon /> Test Completed</h6>
                                    <h4 className="card-number">4/78</h4>

                                </div>
                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card reportcard">
                                <div className="card-body">
                                    <h6 className="card-title">
                                        <AccessAlarmIcon /> Total time spent on test</h6>
                                    <h4 className="card-number">0h 7m</h4>

                                </div>
                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card reportcard">
                                <div className="card-body">
                                    <h6 className="card-title">Your highest score</h6>
                                    <h4 className="card-number">4/720</h4>

                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="card card1">
                                <div className="card-body">
                                    <h4 className="card-title">
                                        card 3</h4>
                                    <p>If you've at least used some form of writing or web content management software, there is a chance you encountered the Lorem Ipsum text.

                                    </p>

                                </div>
                            </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="card card1">
                                <div className="card-body">
                                    <h4 className="card-title">
                                        card 4</h4>
                                    <p>If you've at least used some form of writing or web content management software, there is a chance you encountered the Lorem Ipsum text.

                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="card card1">
                                <div className="card-body">
                                    <h4 className="card-title">card 1</h4>
                                    <p>If you've at least used some form of writing or web content management software, there is a chance you encountered the Lorem Ipsum text.

                                    </p>

                                </div>
                            </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="card card1">
                                <div className="card-body">
                                    <h4 className="card-title">card 2</h4>
                                    <p>If you've at least used some form of writing or web content management software, there is a chance you encountered the Lorem Ipsum text.

                                        .</p>

                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>




    )
}

export default Profile;