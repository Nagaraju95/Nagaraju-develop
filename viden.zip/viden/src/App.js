import React, { Component, useState } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Quiz from './components/Quiz';
import { connect } from 'react-redux';
import { ActionTypes } from './constants/actionTypes';

import Profile from './components/Profile';
import { Route, Switch } from "react-router-dom";
import Navbar from './components/Navbar'
import Report from './components/Report';
import Review from './components/Review';

const mapStateToProps = state => { return { ...state.quiz } };

const mapDispatchToProps = dispatch => ({
  onQuizLoad: payload => dispatch({ type: ActionTypes.QuizLoad, payload }),
  onPagerUpdate: payload => dispatch({ type: ActionTypes.PagerUpdate, payload })
});

class App extends Component {

  isAnswered = (q) => {
    return q.options.some(x => x.selected) ? 'Answered' : 'Not Answered';
  }

  state = {
    quizes: [
      { id: 'data/javascript.json', name: 'Javascript' },
      { id: 'data/aspnet.json', name: 'Asp.Net' },
      { id: 'data/csharp.json', name: 'C Sharp' },
      { id: 'data/designPatterns.json', name: 'Design Patterns' }
    ],
    quizId: 'data/javascript.json'
  };

  pager = {
    index: 0,
    size: 1,
    count: 1
  }

  componentDidMount() {
    this.load(this.state.quizId);
  }

  load(quizId) {
    let url = quizId || this.props.quizId;
    fetch(`../${url}`).then(res => res.json()).then(res => {
      let quiz = res;
      quiz.questions.forEach(q => {
        q.options.forEach(o => o.selected = false);
      });
      quiz.config = Object.assign(this.props.quiz.config || {}, quiz.config);
      this.pager.count = quiz.questions.length / this.pager.size;
      this.props.onQuizLoad(quiz);
      this.props.onPagerUpdate(this.pager);
    });
  }

  onChange = (e) => {
    this.setState({ quizId: e.target.value });
    this.load(e.target.value);
  }



  render() {

    return (
      <div>
        <Navbar />
        <Switch>
          <Route path="/profile" component={Profile} exact />
          <Route path="/report" component={Report} exact />
          <Route path = "/review" component = {Review} exact />
        

          {/* middle content */}
          <div className="main-section">
            {/* <Profile /> */}
            <br /><br />
            <div className="row">
              <div className="col-lg-8">
                <div className="selectbox">
                  <label >Select Subject</label>
                  <select className="form-select form-select-lg mb-4" onChange={this.onChange}>
                    {this.state.quizes.map(q => <option key={q.id} value={q.id}>{q.name}</option>)}
                  </select>
                </div>
                <Quiz quiz={this.state.quiz} quizId={this.state.quizId} mode={this.state.mode} />
              </div>
              <div className="col-lg-4 question_pallete">

                <h2 className="text-center">
                  00:00:00
                </h2>
                <div className="row">
                  <label> Question Palette</label>
                  {this.props.quiz.questions.map((q, index) =>
                    <div key={q.id} className="col-3 text-center p-1">
                      <button id={index} onClick={this.props.move} className={`btn ${this.isAnswered(q) === 'Answered' ? 'palletebtn1' : 'palletebtn2'}`}>{index + 1}</button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Switch>

      </div>


    );


  }

}

export default connect(mapStateToProps, mapDispatchToProps)(App);
